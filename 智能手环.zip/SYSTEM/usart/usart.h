#ifndef __USART_H
#define __USART_H
 
#include "stdio.h" 
#include "rtc.h"
#include "string.h"


void usart_Init(u32 bound);


#endif


