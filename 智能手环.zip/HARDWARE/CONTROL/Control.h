#ifndef __CONTROL_H
#define __CONTROL_H

int get_key(void);
void Game_control(void);

#endif

